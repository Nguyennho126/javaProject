/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.util.Random;

/**
 *
 * @author hp
 */
public class Bee {
    private String type;
    private int health;
    private boolean alive;
    private byte id; 
    
    public Bee() {
        //init
    	setHealth(100) ;
        setAlive(true); 
 }
    public Bee(byte id) {
        //init
    	setId(id);
    	setHealth(100) ;
        setAlive(true); 
 }

    public int getId() {
		return id;
	}

	public void setId(byte id) {
		this.id = id;
	}

	public void setAlive(boolean alive) {
		this.alive = alive;
	}

	
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
        //update the alive status when the health value changed
          
    }   
    
    public boolean isAlive(){
        return this.alive;
    }  
   
    //attack this bee
    public void damage() {
        int random = (int)(Math.random() * 101);
        if (alive ) {
			setHealth((getHealth() - random)<0 ? 0:(getHealth() - random));
	}
    }

    @Override
    public String toString() {
        String beeDetails ="Bee details";
        //your code
        
        if (!alive) {
        	beeDetails ="dead";
        }else {
        	beeDetails ="alive";
        }
        
        return beeDetails;
    }
}
