/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.util.Random;

/**
 *
 * @author hp
 */
public class WorkerBee extends Bee {
     //your code
	  final int dieWhen = 50;
	  public WorkerBee(byte id){
	        super(id);//call base class (Bee) constructor
	        this.setType("Worker");
	    }
	    
	  @Override
		public void damage() {
			// TODO Auto-generated method stub
			super.damage();
			if(getHealth() < dieWhen ) {
				setAlive(false);
				}
		}
	   
}
