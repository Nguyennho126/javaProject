/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ui;

import Business.BeeHive;
import Entity.Bee;

import java.awt.datatransfer.SystemFlavorMap;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author hp
 */
public class Solution {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        BeeHive bh = null;      
        boolean keepRunning = true;
        Scanner s = new Scanner(System.in);
        int choice;
        while (keepRunning) {
            //menu
            System.out.println("--------------Bee hive--------------");
            System.out.println("1- Create bee list");
            System.out.println("2- Attack bees");
            System.out.println("3- Exit");
            System.out.print("Enter your choice (1, 2 or 3): ");
            choice = s.nextInt();
            ArrayList<Bee> bees;
            switch (choice) {
                case 1:
                    bh = new BeeHive();
                    bh.init();//create 10 bees
                    bees = bh.getAllBees();
                    System.out.println("Bees details at the beginning:");
                    showBees(bees);
                    break;
                case 2:
                    if (bh == null) {
                        System.out.println("No bee!");
                    } else {   
                        bh.attackBees();//attach bees
                        bees = bh.getAllBees();  
                        System.out.println("Bees details at the moment:");
                        showBees(bees);
                        int t =0;
                        for (Bee x : bees) {
                        	if (x.isAlive() == false) {
                        		t++;	
                        }
                      if (t ==10) {
                    	  keepRunning = false;
                      }
                    }
                    }
                    break;
                default:
                    keepRunning = false;
            }
        }

    }

    public static void showBees(ArrayList<Bee> bees) {
       //your code
    	for (Bee x: bees) {
    		System.out.printf("%-10d  %-12s  %-12d  %-12s\n",x.getId(),x.getType(),x.getHealth(),x.toString());  
    	}
    }

}
