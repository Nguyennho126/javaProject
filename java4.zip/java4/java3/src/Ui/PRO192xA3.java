/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ui;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;
import java.awt.datatransfer.SystemFlavorMap;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

/*import jdk.nashorn.internal.parser.Lexer;*/
import Business.AllowanceCalulator;
import Business.EmployeeManagement;
import Business.MucDoGiongNhau;
import Entity.EDegree;
import Entity.EPosition;
import Entity.Employee;
import Entity.Staff;
import Entity.Teacher;

/**
 *
 * @author hp
 */
public class PRO192xA3 {
	  
    private static final Comparator<? super Employee> Comparator = null;

	//create an employee by inputing it's attribute values from keyboard
    static Employee createNewImployee() {
        System.out.print("Do you want to create a Staff or a Teacher (enter S for Staff, otherwise for Teacher)?");
        //accept Staff or Teacher details from keyboard        
        Scanner scan = new Scanner(System.in);
        String choice = scan.nextLine();
        if (choice.equalsIgnoreCase("s")) {
            Staff s = new Staff();
            //input staff details
            //your code
            //nhap ten
            boolean t = false;
            do
            {
            System.out.print("FullName:");
            String testName = scan.nextLine();
            if (testName.trim().length() != 0) {
            	t = true;
            	s.setFullName(testName);
            	}else {
            		System.out.println("Erorr: FullName is not null");
            	}
            }while(t == false);
            
            //Nhap khoa
            System.out.print("Department:");
            s.setDepartment(scan.nextLine());
            
          //Nhap ti so luong, nhap lai khi khong phai la so
            t = false;
            do
            {
             System.out.print("Salary ratio:");
                    
               choice = scan.nextLine();
                if (TestNumber.isNumber(choice) == true) {
                    if(Float.parseFloat(choice)> 0) {
                    	t = true;
                    s.setSalaryRatio(Float.parseFloat(choice));
                    }else {
                    	System.out.println("Again! give us a positive number!");
                    }
                } else
                {
                    System.out.println("Again! give us a positive number!");
                }
            } while(t == false);
            
            //nhap vi tri (yeu cau nhap lai khi nhap sai).
             t = false;
            do
            {
             System.out.print("Your Position: please choose 1,2,or 3, (1 -HEAD , 2-VICE_HEAD, 3- STAFF):");
                    
               choice = scan.nextLine();
                if (TestNumber.isNumber(choice) == true) {
                	float rat = Float.parseFloat(choice);
                	
                	if (rat ==1) {
                		s.setPosition(EPosition.HEAD);
                	    t = true;
                	}
                    if (rat ==2) {
                    	s.setPosition(EPosition.VICE_HEAD);
                    	t = true;
                    }
                    if (rat==3) {
                    	s.setPosition(EPosition.STAFF);
                    	t = true;
                    }
                } else
                {
                    System.out.println("again! (1 -HEAD , 2-VICE_HEAD, 3- STAFF)!");
                }
            } while(t == false);
            
            
          
            //nhap so ngay lam viec (nhap lai khi khong phai la so)!
            t = false;
            do
            {
            	 System.out.print("Number of working days:");
                //accept Staff or Teacher details from keyboard        
               choice = scan.nextLine();
                if (TestNumber.isNumber(choice) == true) {
                	 if(Float.parseFloat(choice)> 0) {
                     	t = true;
                     s.setNoOfWorkingDay(Float.parseFloat(choice));
                     }else {
                     	System.out.println("Again! give us a positive number!");
                     }
                 } else
                 {
                     System.out.println("Again! give us a positive number!");
                 }
             } while(t == false);
            return s;
             }else {
            Teacher t = new Teacher(); 
            //nhap vao giao vien moi
            //inputs Teacher details
            //your code
            
            boolean s = false;
            do
            {
            System.out.print("FullName:");
            String testName = scan.nextLine();
            if (testName.trim().length() != 0) {
            	s = true;
            	 t.setFullName(testName);
            	}else {
            		System.out.println("Erorr: FullName is not null");
            	}
            }while(s == false);
           
     
            
            
            System.out.print("Faculty:");
            t.setFaculty(scan.nextLine());
            s = false;
            do 
            {
            	System.out.print("Salary ratio:");
                //accept Staff or Teacher details from keyboard        
               choice = scan.nextLine();
                if (TestNumber.isNumber(choice) == true) {
                	 if(Float.parseFloat(choice)> 0) {
                      	s= true;
                      t.setSalaryRatio(Float.parseFloat(choice));
                      }else {
                      	System.out.println("Again! give us a positive number!");
                      }
                  } else
                  {
                      System.out.println("Again! give us a positive number!");
                  }
              } while(s== false);
           // nhap vi tri cua giao vien
             s = false;
            do
            {
             System.out.print("Position: please choose 1,2,or 3, (1 - BACHELOR, 2-MASTER, 3- DOCTOR):");
                    
               choice = scan.nextLine();
                if (TestNumber.isNumber(choice) == true) {
                	float rat = Float.parseFloat(choice);
                	
                	if (rat ==1) {
                		t.setDegree(EDegree.BACHELOR);;
                	    s = true;
                	}
                    if (rat ==2) {
                    	t.setDegree(EDegree.MASTER);
                    	s = true;
                    }
                    if (rat==3) {
                    	t.setDegree(EDegree.DOCTOR);;
                    	s = true;
                    }
                } else
                {
                    System.out.println("Again! (1 - BACHELOR, 2-MASTER, 3- DOCTOR):");
                }
            } while(s == false);
           // nhap gio lam viec, nap lai neu nhap sai
            s = false;
            do
            {
            	   System.out.print("Number of teaching hours:");
                //accept Staff or Teacher details from keyboard        
               choice = scan.nextLine();
                if (TestNumber.isNumber(choice) == true) {
                	 if(Float.parseFloat(choice)> 0) {
                     	s= true;
                     t.setTeachingHours(Float.parseFloat(choice));
                     }else {
                     	System.out.println("Again! give us a positive number!");
                     }
                 } else
                 {
                     System.out.println("Again! give us a positive number!");
                 }
             } while(s== false);
            return t;
        }

    }

    //display a list of employee
    static void display(ArrayList<Employee> listE) throws IOException {
        /*System.out.printf("%1$-10s\n", "Results:");*/
        /*System.out.println("Name, Fac/Dept, Deg/Pos, Sal Ratio, Allowance, T.Hours/W.Days, Salary");*/
        System.out.println("--------------------*****Results****---------------------");
        System.out.printf("%-5s%-25s  %-15s %-12s %-12s  %-12s  %-24s  %-12s %n","Id","Name","Fac/Dept","Deg/Pos","Sal_Ratio",
        		"Allowance","T.Hours/W.Days","Salary");
        int i=1;
        for (Employee e : listE) {
        	e.setId(i);
        	if(e instanceof Staff) {
        			System.out.printf("%-5d%-25s  %-15s %-11s  %-13.2f %-13.0f %-25.0f %-12.3f%n",e.getId(),
        		    e.getFullName(),((Staff) e).getDepartment(),((Staff) e).getPosition(),
        		    e.getSalaryRatio(),e.getAllowance(),((Staff) e).getNoOfWorkingDay(), e.getSalary());
            	}
        		
            if(e instanceof Teacher) {
            	System.out.printf("%-5d%-25s  %-15s %-11s  %-13.2f %-13.0f %-25.0f %-12.3f%n",e.getId(),
            	 e.getFullName(),((Teacher) e).getFaculty(),((Teacher) e).getDegree(),
            	 e.getSalaryRatio(),e.getAllowance(), ((Teacher) e).getTeachingHours(),e.getSalary());
            	}
        	/*System.out.println(e);*/
            i++;
        }
    
    }

    public static void main(String[] args) throws IOException {
        // create employee management object
        EmployeeManagement empMan = new EmployeeManagement();
        //menu
        EmployeeManagement.isFile("data.txt");
        Scanner scan = new Scanner(System.in);
        ArrayList<Employee> listE = empMan.listAll();
       int  choice = 1 ;
       String path;
       
        boolean keepRunning = true;
        while (keepRunning) {
                 boolean k = false;
                 // bao nhap lai khi nhap khong phai la cac so 1 2 3 4 5 6 7 8.
                 do{
                	System.out.println("University Staff Management 1.0");
                    System.out.println("\t1.Add staff, save in file data.txt ");
                    System.out.println("\t2.Search staff by name");
                    System.out.println("\t3.Search staff by department/faculty");
                    System.out.println("\t4.Display all staff");
                    System.out.println("\t5.Save as");
                    System.out.println("\t6.Load Data from newFileText");
                    System.out.println("\t7.Remove staff by Id");
                    System.out.println("\t8.Exit");
                    
                   System.out.print("Select function (1,2,3,4,5,6,7,8): ");
                   String  sTr = scan.nextLine();
                   try {
                    if (TestNumber.isNumber(sTr) == true) {
						float choice1 = Float.parseFloat(sTr); 
                         if (choice1 == 1 || choice1 == 2 || choice1 == 3 || choice1 == 4 
                        		 || choice1 ==5|| choice1 ==6|| choice1 ==7|| choice1==8) {
                        	k = true; 
                            choice = (int)(choice1);
                     } else
                     {
                         System.out.println("again!");
                     }
                     }
                   }catch(Exception e) {
                	   System.out.println("Again!");
                   }
                 }while(k == false);
             
            switch (choice) {
                case 1://add staff/teacher    
                    Employee emp = createNewImployee();
                    float allowance = AllowanceCalulator.calculateAllowance(emp);
                    emp.setAllowance(allowance);
                    empMan.addEmployee(emp);
                    Business.EmployeeManagement.save(emp, "data.txt");
                    break;
                case 2://search by name                    
                    System.out.print("\tEnter name to search: ");
                    scan = new Scanner(System.in);
                    String name = scan.nextLine();
                    ArrayList<Employee> foundByName = empMan.searchByName(name);
                    display(foundByName);
                    
                    break;
                case 3://search by dept
                    System.out.print("\tEnter dept/fac to search: ");
                    scan = new Scanner(System.in);
                    String dept = scan.nextLine();
                    ArrayList<Employee> foundByDept = empMan.searchByDept(dept);
                    display(foundByDept);
                    break;
                case 4://display all
                    listE =  EmployeeManagement.load("data.txt")  ;
                    listE.sort(Comparator);
                    display(listE);
                    break;
                case 5://save as
                	System.out.print("Give me a path to save as:");
                	try {
                    path  = scan.nextLine();
                    for (Employee x: listE) {
                    Business.EmployeeManagement.save(x, path);
                    }
                    break;
                	}catch(Exception e) {
                		
                	}
                case 6://Load Data from your fileText (load va nap vao he thong).
                	System.out.print("Give me a path to load:");
                    path  = scan.nextLine();
                    ArrayList<Employee> listLoad1 =  EmployeeManagement.load(path)  ;
                    for (Employee e:listLoad1) {
                        listE.add(e);
                        Business.EmployeeManagement.save(e, "data.txt");
                        }
                        listE.sort(Comparator);
                        display(listE);
                    break;
                case 7://xoa theo Id
                	System.out.print("Give me a Id to delete its row:");
                	try {
                     int id = scan.nextInt();
                     if(0 <id && id < listE.size()+1) {
                    listE.remove(id-1);
                    PrintWriter writer = new PrintWriter("data.txt");
                    writer.print("");
                    writer.close();
                    for (Employee x: listE) {
                        Business.EmployeeManagement.save(x, "data.txt");
                        }
                    
                     }else { 
                    	 System.out.println("Id is not in data");
                     }
                     }catch(Exception e){
                    	 System.out.println("Id is not positive integer number");
                	}
                    break;
                case 8://exit
                    keepRunning = false;
                    
               }
            
          } 
       
    }
}
