package Ui;

public class TestNumber {
		public static boolean isNumber(String sData) {
			boolean t =false;
			 for (int j = 0; j < sData.length(); j++) { 
		            if (Character.isLetter(sData.charAt(j))) { 
		               t = false; 
		                break; 
		            } 
		            if (j + 1 == sData.length()) { 
		                t =true; 
		            } 
		        }
			return t;
		}
}
