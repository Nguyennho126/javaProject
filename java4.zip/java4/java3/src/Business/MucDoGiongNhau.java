package Business;
import java.util.Scanner;
public class MucDoGiongNhau {
	public static  void  PhanTram() {};
	public static  float PhanTram(String a, String b) {
		int i = a.length();
		int j = b.length();
		int k = Math.min(i,j);
		char[] char1 = a.toLowerCase().toCharArray();
		char[] char2 = b.toLowerCase().toCharArray();
		int giong = 0;
		for (int t = 0; t< i; t++) {
			for (int z= 0; z<j;z++) {
				if (char1[t] == char2[z] ) {
					giong++;
					break;
				}
			}
		}
		return giong/k*100; 
	}
}
// code nay mo ta muc do giong nhau cua "abc" va "abcd" la 100%  
