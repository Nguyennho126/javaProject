/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.stream.Stream;

import javax.swing.JSpinner.ListEditor;
import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MaximizeAction;
import javax.swing.text.html.parser.Entity;

import Entity.EDegree;
import Entity.EPosition;
import Entity.Employee;
import Entity.Staff;
import Entity.Teacher;

/**
 *
 * @author hp
 */
public class EmployeeManagement {

    private static final Comparator<? super Employee> Comparator = null;
	//store all staff/teacher
    static ArrayList<Employee> listE;
    public EmployeeManagement() {        
        listE = new ArrayList<>();
    }

    public void addEmployee(Employee emp) {
        //add emp to listE
        //your code
    	listE.add(emp);
    }
    
    
    
    
    //search by staff/teacher's name
    public  ArrayList<Employee> searchByName(String name) {
        //store all matching staff or teacher
        ArrayList<Employee> empFound = new ArrayList<>();
        //your code
        for(Employee x:listE) {
        	if (MucDoGiongNhau.PhanTram(x.getFullName(),name)> 80 ){
        		empFound.add(x);}
        	}
        	
         return empFound;
    }
    //search by staff/teacher's department/faculty
    public ArrayList<Employee> searchByDept(String dept) {
        ArrayList<Employee> empFound = new ArrayList<>();
        //your code
        
        for(Employee x:listE) {
        	if(x instanceof Staff) {
        		if (MucDoGiongNhau.PhanTram(((Staff) x).getDepartment(),dept)> 80 ){
            		empFound.add(x);}
            	}
        		
            if(x instanceof Teacher) {
        		if (MucDoGiongNhau.PhanTram(((Teacher) x).getFaculty(),dept)> 80 ){
            		empFound.add(x);}
            	}
        }
        
        return empFound;
    }
    //we can use instanceof to search staff/teacher via department/faculty.
    public ArrayList<Employee> listAll() {
        //sort the list of staff/teacher before return
        //your code
    	listE.sort(Comparator);
        return listE;
    }
    //kiem tra file ton tai hay khong.
    public  static void isFile(String fileName) {
    	try {
    		File file = new File(fileName);
    		if(file.isFile() == false) {
    			System.out.println("Error: ****load Data:"+ fileName + " file not found!");
    		}
    	}catch(Exception e) {
    		System.out.println(e);
    	}
    	
    }
    
    // save Emplyee(Staff/Teacher).(for assignment) 
    public  static void save(Employee emp, String fileName) throws IOException {
   	PrintWriter pw = null;

    	  try {
    	     File file = new File(fileName);
    	     FileWriter fw = new FileWriter(file, true);
    	     pw = new PrintWriter(fw);
    	     pw.println("");
    	     pw.println(emp.toString());
    	  } catch (IOException e) {
     	     e.printStackTrace(); 
     	  } finally {
    	     if (pw != null) {
    	        pw.close();
    	     }
    	  }
    }
	//for asigment 4, trả về đối tượng lưu thông tin file nhập vào. (try-catch kiem tra thuoc tinh du liêu).
    public static  ArrayList<Employee> load(String fileName){
		//bạn hãy thay đổi đường dẫn tới file của bạn
//		int []i ={0};//i là biến đếm xem chúng ta đã in tới dòng nào
    	ArrayList<Employee> ListLoad = new ArrayList<>();
    	
    	int []i ={0};// bien dem xem chung ta toi dong nao
		try(Stream<String> stream = Files.lines(Paths.get(fileName),StandardCharsets.UTF_8)){//đưa về dạng chuẩn utf8
			stream.forEach(line ->{
				//line là từng dòng trong file, tại đây bạn có thể tương tác với nội dung của file. Ở đây, mình chỉ in ra nội dung của từng dòng
				
					String []array = line.split(",");
					
//				System.out.println(line +" is number line "+ i[0]++);//in ra cả nội dung file và dòng thứ mấy ta vừa in, bắt đầu từ 0
				if (array[0].trim().equalsIgnoreCase("Staff")&&array.length ==8) {
					Staff s = new Staff();
					// try-catch name, tra ve loi neu nhap rong.
					try {
					s.setFullName(array[1].trim());
				    int n = array[1].trim().length();
					float y = 1/n;
					}catch(Exception e) {
						System.out.println("Error: FullName of fileText is Null!"+" line"+ i[0]++);
					}
					
					try {
						s.setDepartment(array[2].trim());
					    int n = array[2].trim().length();
						float y = 1/n;
						}catch(Exception e) {
							System.out.println("Error: Department  of fileText is Null!"+" line"+ i[0]++);
						}
				
					for(EPosition x : EPosition.values()) {
						if(x.toString().equalsIgnoreCase(array[3].trim())) {
							s.setPosition(x);
							break;
						}
					}
					try {
					s.setSalaryRatio(Float.parseFloat(array[4]));
					}catch(Exception e) {
						System.out.println("Error: SalaryRatio is not float form,"+" line"+ i[0]++);
					}
					try {
					float allowance = AllowanceCalulator.calculateAllowance(s);
					s.setAllowance(allowance);
					//kiem tra Allowance nhap vao co khop voi tinh toan khong?
					if ((allowance - Float.parseFloat(array[5])) !=0) {
						System.out.println("Error: Allowance of fileText is wrong!"+" line"+ i[0]++);
					}
					}catch(Exception e) {
						System.out.println("Error: Allowance of fileText is not float form!"+" line"+ i[0]++);
						}
					//try-catch so working days
					try {
						s.setNoOfWorkingDay(Float.parseFloat(array[6]));
						}catch(Exception e) {
							System.out.println("Error: WorkingDay of fileText is not float form,"+" line"+ i[0]++);
						}
					//kiem tra Allowance nhap vao co khop voi tinh toan khong?
					try {
					if ((s.getSalary() - Float.parseFloat(array[7])) !=0) {
						System.out.println("Error: Salary of fileText is not true!"+" line" + i[0]++);
					}
					}catch(Exception e) {
						System.out.println("Error: Salary of fileText is not float form!"+" line:"+ i[0]++);
						}
					ListLoad.add(s);
					//load teacher 
					
	    }else if(array[0].trim().equalsIgnoreCase("Teacher") && array.length ==8) {
						Teacher s = new Teacher();
						// try-catch name, tra ve loi neu nhap rong.
						try {
						s.setFullName(array[1].trim());
					    int n = array[1].trim().length();
						float y = 1/n;
						}catch(Exception e) {
							System.out.println("Error: FullName of fileText is Null!"+" line of File:"+ i[0]++);
						}
						
						try {
							s.setFaculty(array[2].trim());
						    int n = array[2].trim().length();
							float y = 1/n;
							}catch(Exception e) {
								System.out.println("Error: Faculty of fileText is Null!"+" line of File:"+ i[0]++);
							}
					
						for(EDegree x : EDegree.values()) {
							if(x.toString().equalsIgnoreCase(array[3].trim())) {
								s.setDegree(x);
								break;
							}
						}
						try {
						s.setSalaryRatio(Float.parseFloat(array[4]));
						}catch(Exception e) {
							System.out.println("Error: SalaryRatio of fileText is not float form! "+" line of File:"+ i[0]++);
						}
						try {
						float allowance = AllowanceCalulator.calculateAllowance(s);
						s.setAllowance(allowance);
						//kiem tra Allowance nhap vao co khop voi tinh toan khong?
						if ((allowance - Float.parseFloat(array[5])) !=0) {
							System.out.println("Error: Allowance of fileText has a problem! "+" line"+ i[0]++);
						}
						}catch(Exception e) {
							System.out.println("Error: Allowance of fileText is not float form! "+" line"+ i[0]++);
							}
						//try-catch so 
						try {
							s.setTeachingHours(Float.parseFloat(array[6]));
							}catch(Exception e) {
								System.out.println("Error: TeachingHours is not float form! "+" line"+ i[0]++);
							}
						//kiem tra Allowance nhap vao co khop voi tinh toan khong?
						try {
						if ((s.getSalary() - Float.parseFloat(array[7])) !=0) {
							System.out.println("Error: Salary of fileText is not true! "+" line:"+ i[0]++);
						}
						}catch(Exception e) {
							System.out.println("Error: Salary of fileText is not float form!"+" line:"+ i[0]++);
							}
						ListLoad.add(s);
	    }else {
	    }	
				
					});
		} catch (FileNotFoundException e) {
			System.out.println("Error: ****load Data:"+ fileName + " file not found!");
		}catch (Exception e) {
			e.printStackTrace();
			
		}ListLoad.sort(Comparator); 
		return ListLoad;
	}
    /*System.out.println("Name, Fac/Dept, Deg/Pos, Sal Ratio, Allowance, T.Hours/W.Days, Salary");*/
}

