/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import Entity.EDegree;
import Entity.EPosition;
import Entity.Employee;
import Entity.Staff;
import Entity.Teacher;

/**
 *
 * @author hp
 */
public class AllowanceCalulator {
     /*
    for teacher:
    bachelor/cá»­ nhÃ¢n 300
    master/tháº¡c sÄ© 500
    doctor/tiáº¿n sÄ© 1000
    
    for staff:
    head/trÆ°á»Ÿng phÃ²ng 2000
    vice-head/phÃ³ phÃ²ng 1000
    staff/nhÃ¢n viÃªn 500
    */
    public static float calculateAllowance(Employee emp){        
        float allowance=0;
        if(emp instanceof Staff){
            Staff s = (Staff) emp;
            //head/trưởng phòng 2000
            if(s.getPosition()==EPosition.HEAD) allowance = 2000;
            
            //vice-head/phó phòng 1000
            if(s.getPosition()==EPosition.VICE_HEAD) allowance = 1000;
            //your code
            
            //staff/nhân viên 500  
            if(s.getPosition()==EPosition.STAFF) allowance = 500;
            //your code
            
        }
        if(emp instanceof Teacher){
            Teacher t = (Teacher) emp;
           //your code  
          //Bachelor/ cử nhân  300
            if(t.getDegree()== EDegree.BACHELOR) allowance = 300;
            
           // master/thạc sĩ 500
            if(t.getDegree()== EDegree.MASTER) allowance = 500;
            //your code
            
            //doctor/tiến sĩ 1000 
            if(t.getDegree()== EDegree.DOCTOR) allowance = 1000;
            //your code
            
        }
        return allowance;
    }
}
