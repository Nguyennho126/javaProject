/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

//enumerate position of a staff
public enum EPosition {
    HEAD,VICE_HEAD,STAFF
}
 