package Entity;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import Business.AllowanceCalulator;
import Business.EmployeeManagement;

class UnitTestSearch {

	@Test
	void testSearchName() {
		Teacher t = new Teacher();
		t.setId(1);
		t.setFullName("testTeacher");
		t.setFaculty("It");
		t.setSalaryRatio(3.2f);
		t.setTeachingHours(25f);
		t.setDegree(EDegree.BACHELOR);
		float allowance = AllowanceCalulator.calculateAllowance(t);
        t.setAllowance(allowance);
        EmployeeManagement eMg =new EmployeeManagement();
        eMg.addEmployee(t);
        ArrayList<Employee> listE = eMg.searchByName("test");
        int v = 0;
        for(Employee e :listE) {
        	if(t==e) {
        		v=1;
        		break;
        	}
        }
        assertEquals(1,v);//test =1 thi code dung, test = 0 thi code sai
	}
	@Test
	void testSearchDep() {
		Teacher t1 = new Teacher();
		t1.setId(2);
		t1.setFullName("testTeacher1");
		t1.setFaculty("It Fpt");
		t1.setSalaryRatio(3.1f);
		t1.setTeachingHours(25f);
		t1.setDegree(EDegree.MASTER);
		float allowance = AllowanceCalulator.calculateAllowance(t1);
        t1.setAllowance(allowance);
        EmployeeManagement eMg =new EmployeeManagement();
        eMg.addEmployee(t1);
        ArrayList<Employee> listE = eMg.searchByDept("");
        int v = 0;
        for(Employee e :listE) {
        	if(t1==e) {
        		v=1;
        		break;
        	}
        }
        assertEquals(1,v);//test =1 thi code dung, test = 0 thi code sai
	}
}

