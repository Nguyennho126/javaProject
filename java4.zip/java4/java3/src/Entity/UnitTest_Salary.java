package Entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Business.AllowanceCalulator;

class UnitTest_Salary {
 //test luong giao vien
	@Test
	void testBACHELOR() {
		
		Teacher t = new Teacher();
		t.setId(1);
		t.setFullName("testTeacher1");
		t.setFaculty("It");
		t.setSalaryRatio(3.2f);
		t.setTeachingHours(25f);
		t.setDegree(EDegree.BACHELOR);
		float allowance = AllowanceCalulator.calculateAllowance(t);
        t.setAllowance(allowance);	
        assertEquals(3761f, t.getSalary());
	}
	@Test
	void testDOCTOR() {
		
		Teacher t = new Teacher();
		t.setId(2);
		t.setFullName("testTeacher2");
		t.setFaculty("It");
		t.setSalaryRatio(2.5f);
		t.setTeachingHours(35f);
		t.setDegree(EDegree.DOCTOR);
		float allowance = AllowanceCalulator.calculateAllowance(t);
        t.setAllowance(allowance);	
        assertEquals(4400f, t.getSalary());
	}
	@Test
	void testMASTER() {
		
		Teacher t = new Teacher();
		t.setId(3);
		t.setFullName("testTeacher3");
		t.setFaculty("It");
		t.setSalaryRatio(2.1f);
		t.setTeachingHours(50f);
		t.setDegree(EDegree.MASTER);
		float allowance = AllowanceCalulator.calculateAllowance(t);
        t.setAllowance(allowance);	
        assertEquals(4283f, t.getSalary());
	}
	//testluong Staff
	@Test
	void testHead() {
		
		Staff s = new Staff();
		s.setId(1);
		s.setFullName("staff1");
		s.setDepartment("It");
		s.setSalaryRatio(3.8f);
		s.setNoOfWorkingDay(64f);
		s.setPosition(EPosition.HEAD);
		float allowance = AllowanceCalulator.calculateAllowance(s);
        s.setAllowance(allowance);	
        assertEquals(6694f, s.getSalary());
	}
	
	@Test
	void testVICE_HEAD() {
		
		Staff s = new Staff();
		s.setId(2);
		s.setFullName("staff1");
		s.setDepartment("It");
		s.setSalaryRatio(1.3f);
		s.setNoOfWorkingDay(36f);
		s.setPosition(EPosition.VICE_HEAD);
		float allowance = AllowanceCalulator.calculateAllowance(s);
        s.setAllowance(allowance);	
        assertEquals(3029f, s.getSalary());
	}
	@Test
	void testStaff() {
		
		Staff s = new Staff();
		s.setId(1);
		s.setFullName("staff1");
		s.setDepartment("It");
		s.setSalaryRatio(2.9f);
		s.setNoOfWorkingDay(54f);
		s.setPosition(EPosition.STAFF);
		float allowance = AllowanceCalulator.calculateAllowance(s);
        s.setAllowance(allowance);	
        assertEquals(4237f, s.getSalary());
	}
}
