
java version (JDK) "9.0.4"
Java(TM) SE Runtime Environment (build 9.0.4+11)
Java HotSpot(TM) 64-Bit Server VM (build 9.0.4+11, mixed mode).
Write on Elcipse!

Unit tests  is written the package Unity.
--------****------
University Staff Management 1.0
	1.Add staff, save in file data.txt 
	2.Search staff by name
	3.Search staff by department/faculty
	4.Display all staff
	5.Save as
	6.Load Data from newFileText
	7.Remove staff by Id
	8.Exit
Select function (1,2,3,4,5,6,7,8): 1
Do you want to create a Staff or a Teacher (enter S for Staff, otherwise for Teacher)?