package assigment1;

import java.util.Scanner;

public class bai6 {
	public static void main(String agrv[])
    {
	  System.out.println("Could you please give me your string:" ); //Lenh in ra man hinh
	  Scanner inp = new Scanner(System.in);
	  String string = inp.nextLine();
	  char[] newstring = string.toCharArray();
	  int l = newstring.length;
	  System.out.println("Length of your string is "+l );
    }

}
