package assigment1;

import java.util.Scanner;

public class bai1
{
    public static void main(String agrv[])
    {
        int x;
        int y;
        int z;
        Scanner inp = new Scanner(System.in); //tao doi tuong inp thuoc lop Scanner
        System.out.print("the first number : "); //Lenh in ra man hinh
        x = inp.nextInt(); //nhap chuoi
        System.out.print("the second number: ");
        y = inp.nextInt(); //nhap so nguyen
        System.out.print("the thirst number: ");
        z = inp.nextInt();
       
    	bai1(x,y,z);
    }
    public static void bai1(int x,int y,int z) {
         int max;
         int min;
     /*    Scanner inp = new Scanner(System.in); //tao doi tuong inp thuoc lop Scanner
         System.out.print("the first number : "); //Lenh in ra man hinh
         x = inp.nextInt(); //nhap chuoi
         System.out.print("the second number: ");
         y = inp.nextInt(); //nhap so nguyen
         System.out.print("the thirst number: ");
         z = inp.nextInt();
         */
         max=Math.max(Math.max(x,y),z);
 	min=Math.min(Math.min(x,y),z);
 	System.out.println("Max l�:"+max);
 	System.out.println("Min l�:"+min);
 	
        
    }
}