package assigment1;

import java.util.Scanner;

public class bai5 {
	public static void main(String agrv[])
    {
	  System.out.println("Could you please give me your string:" ); //Lenh in ra man hinh
	  Scanner inp = new Scanner(System.in);
	  String string = inp.nextLine();
	  char[] newstring = string.toCharArray();
	  int j;
	  boolean  k = false;
	  int l = newstring.length;
	  for (int i=0; i<l;i++) {
		  j= l-i-1;
		  if(newstring[i] != newstring[j]) {
			  k= true;
			  break;
		  }
	  }
	  if (k == true) {
		  System.out.print("Your string is not reflexive" ); //Lenh in ra man hinh
	  }else {
		  System.out.print("Your string is reflexive" );
	  }
    }
}
