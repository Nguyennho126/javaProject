package assigment1;

import java.util.Scanner;

public class bai8 {
	public static void main(String[] agrs) {
		int x = 1;
		int sum =0;
		while (x != 0) {
	      System.out.println("Nhập số nguyên bất kì, dừng lại khi nhập số 0:" );
	      Scanner inp = new Scanner(System.in);
	   	  x = inp.nextInt();
	   	  sum = sum +x;
	     }
	 
	System.out.println("tổng các số đã nhập là:" + sum);
	}
}

