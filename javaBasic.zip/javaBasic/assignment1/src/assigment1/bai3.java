package assigment1;

import java.util.Scanner;

public class bai3 {
	  public static void main(String agrv[])
	    {
		  int array[];
		  array = new int[10];
		  Scanner inp = new Scanner(System.in);
		  int s;
		  for (int i=0; i<10;i++) {
			  s = i+1;
			  System.out.print(" the number " + s + ":" ); //Lenh in ra man hinh
		      array[i] = inp.nextInt(); //nhap chuoi
		  }
		  int max = array[0];
		  for (int i = 1; i<10; i++) {
			  if(array[i] > max) {
				  max = array[i];
			  }
			  
		  }
		  System.out.print(" max of 10 number is: " + max);
		  
	    }
}
