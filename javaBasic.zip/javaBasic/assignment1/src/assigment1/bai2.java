package assigment1;

import java.util.Scanner;

public class bai2 {
    public static void main(String agrv[])
    {
        int a;
        int b;
        int c;
        Scanner inp = new Scanner(System.in); //tao doi tuong inp thuoc lop Scanner
        System.out.print("the first edge : "); //Lenh in ra man hinh
        a = inp.nextInt(); //nhap chuoi
        System.out.print("the second edge: ");
        b = inp.nextInt(); //nhap so nguyen
        System.out.print("the thirst edge: ");
        c= inp.nextInt();
        if ((a>0)&&(b>0)&&(c>0)&&(a + b > c) && (a + c > b) && (b + c > a)) {
        	if ((a == b) && (b == c) && (c == a)) {
				System.out.println("This is an equilateral triangle!");
				} else if((a==b) || (b==c) || (c ==a)) {
				System.out.println("This is an  isosceles triangle !");
				} else {
				System.out.println("This is an  simple triangle !");
					}
        	
			} else  {
			System.out.println("this is not a triangle");
		}
       
    }
}