package assigment1;

import java.util.Scanner;

public class bai7 {
	public static void main(String agrv[])
    {
	  int s;
	  int array1[];
	  array1 = new int[5];
	  Scanner inp1 = new Scanner(System.in);
	  
	  System.out.println("The first array of  5 number elements:" );
	  for (int i=0; i<5;i++) {
		  s = i+1;
		  System.out.print(" the number " + s + ":" ); //Lenh in ra man hinh
	      array1[i] = inp1.nextInt(); //nhap chuoi
	  }
	  int array2[];
	  array2 = new int[5];
	  Scanner inp2 = new Scanner(System.in);
	
	  System.out.println("The second array of  5 number elements:" );
	  for (int i=0; i<5;i++) {
		  s = i+1;
		  System.out.print(" the number " + s + ":" ); //Lenh in ra man hinh
	      array2[i] = inp2.nextInt(); //nhap chuoi
	  }
	  boolean f = true;
	  for (int i=0;i<5;i++) {
		  if(array1[i] != array2[i]) {
			  f = false;
			  break;
		  }
	  }
	  if(f==true) {
		  System.out.println("Two arrays are agree!");
	  }else {
		  System.out.println("Two arrays are not agree, they are different at:");
		  for (int j = 0; j<5; j++) {
			  if(array1[j] != array2[j]) {
				  s =j+1;
				  System.out.println(" the number " + s + ":"+ array1[j] +"|" + array2[j] );  
			  }
			  
		  }
		  
	  }
	 
	 
	  
    }
}
