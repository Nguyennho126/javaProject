package assigment1;

import java.util.Scanner;

public class bai4{
	public static void main(String agrv[])
    {
	  int array[];
	  array = new int[10];
	  Scanner inp = new Scanner(System.in);
	  int s;
	  for (int i=0; i<10;i++) {
		  s = i+1;
		  System.out.print(" the number " + s + ":" ); //Lenh in ra man hinh
	      array[i] = inp.nextInt(); //nhap chuoi
	  }
	  System.out.println("Invert of your number string");
	  for (int i = 9; i > -1; i--) {
		  System.out.print(array[i]+ " ");
		  }
    }
		  
	  
}
