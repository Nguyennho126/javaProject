package assigment1;

import java.util.Scanner;

public class bai10 {
	public static void main(String[] args) {
	int a = 1;
	do {
		System.out.println("----" +"Give me your choice 0,...,9. 0-out "+"----");
		Scanner inp = new Scanner(System.in);
		a = inp.nextInt();
		switch (a) {
			case 1: bai1(); break;
			case 2: bai2(); break;
			case 3: bai3(); break;
			case 4: bai4(); break;
			case 5: bai5(); break;
			case 6: bai6(); break;
			case 7: bai7(); break;
			case 8: bai8(); break;
			case 9: bai9(); break;
	}
	}while (a != 0);
	}
	private static void bai1() {
		System.out.println(" *Find the max and min of three numbers*");
		int x;
        int y;
        int z;
        int max;
        int min;
        Scanner inp = new Scanner(System.in); //tao doi tuong inp thuoc lop Scanner
        System.out.print("the first number : "); //Lenh in ra man hinh
        x = inp.nextInt(); //nhap chuoi
        System.out.print("the second number: ");
        y = inp.nextInt(); //nhap so nguyen
        System.out.print("the thirst number: ");
        z = inp.nextInt();
        max=Math.max(Math.max(x,y),z);
	min=Math.min(Math.min(x,y),z);
	System.out.println("Max là:"+max);
	System.out.println("Min là:"+min);
	 }
	
	private static void bai2() {
		System.out.println(" *Type of triangle*");
		int a;
        int b;
        int c;
        Scanner inp = new Scanner(System.in); //tao doi tuong inp thuoc lop Scanner
        System.out.print("the first edge : "); //Lenh in ra man hinh
        a = inp.nextInt(); //nhap chuoi
        System.out.print("the second edge: ");
        b = inp.nextInt(); //nhap so nguyen
        System.out.print("the thirst edge: ");
        c= inp.nextInt();
        if ((a>0)&&(b>0)&&(c>0)&&(a + b > c) && (a + c > b) && (b + c > a)) {
        	if ((a == b) && (b == c) && (c == a)) {
				System.out.println("This is an equilateral triangle!");
				} else if((a==b) || (b==c) || (c ==a)) {
				System.out.println("This is an  isosceles triangle !");
				} else {
				System.out.println("This is an  simple triangle !");
					}
        	
			} else  {
			System.out.println("this is not a triangle");
		}
	}
	
	private static void bai3() {
		System.out.println(" *max of 10 number*");
		  int array[];
		  array = new int[10];
		  Scanner inp = new Scanner(System.in);
		  int s;
		  for (int i=0; i<10;i++) {
			  s = i+1;
			  System.out.print(" the number " + s + ":" ); //Lenh in ra man hinh
		      array[i] = inp.nextInt(); //nhap chuoi
		  }
		  int max = array[0];
		  for (int i = 1; i<10; i++) {
			  if(array[i] > max) {
				  max = array[i];
			  }
			  
		  }
		  System.out.println(" max of 10 number is: " + max);
		  
	}
	private static void bai4() {
		System.out.println(" *Converse of your number string*");
		int array[];
		  array = new int[10];
		  Scanner inp = new Scanner(System.in);
		  int s;
		  for (int i=0; i<10;i++) {
			  s = i+1;
			  System.out.print(" the number " + s + ":" ); //Lenh in ra man hinh
		      array[i] = inp.nextInt(); //nhap chuoi
		  }
		  System.out.println("Converse of your number string");
		  for (int i = 9; i > -1; i--) {
			  System.out.print(array[i]+ " ");
			  }
	}
	private static void bai5() {
		System.out.println("Could you please give me your string:" ); //Lenh in ra man hinh
		  Scanner inp = new Scanner(System.in);
		  String string = inp.nextLine();
		  char[] newstring = string.toCharArray();
		  int j;
		  boolean  k = false;
		  int l = newstring.length;
		  for (int i=0; i<l;i++) {
			  j= l-i-1;
			  if(newstring[i] != newstring[j]) {
				  k= true;
				  break;
			  }
		  }
		  if (k == true) {
			  System.out.println("Your string is not reflexive" ); //Lenh in ra man hinh
		  }else {
			  System.out.println("Your string is reflexive" );
		  }
	}
	private static void bai6() {
		System.out.println("Could you please give me your string:" ); //Lenh in ra man hinh
		  Scanner inp = new Scanner(System.in);
		  String string = inp.nextLine();
		  char[] newstring = string.toCharArray();
		  int l = newstring.length;
		  System.out.println("Length of your string is "+l );
	}
	private static void bai7() {
		System.out.println("*Compare two number arrays* ");
		int s;
		  int array1[];
		  array1 = new int[5];
		  Scanner inp1 = new Scanner(System.in);
		  
		  System.out.println("The first array of  5 number elements:" );
		  for (int i=0; i<5;i++) {
			  s = i+1;
			  System.out.print(" the number " + s + ":" ); //Lenh in ra man hinh
		      array1[i] = inp1.nextInt(); //nhap chuoi
		  }
		  int array2[];
		  array2 = new int[5];
		  Scanner inp2 = new Scanner(System.in);
		
		  System.out.println("The second array of  5 number elements:" );
		  for (int i=0; i<5;i++) {
			  s = i+1;
			  System.out.print(" the number " + s + ":" ); //Lenh in ra man hinh
		      array2[i] = inp2.nextInt(); //nhap chuoi
		  }
		  boolean f = true;
		  for (int i=0;i<5;i++) {
			  if(array1[i] != array2[i]) {
				  f = false;
				  break;
			  }
		  }
		  if(f==true) {
			  System.out.println("Two arrays are agree!");
		  }else {
			  System.out.println("Two arrays are not agree, they are different at:");
			  for (int j = 0; j<5; j++) {
				  if(array1[j] != array2[j]) {
					  s =j+1;
					  System.out.println(" the number " + s + ":"+ array1[j] +"|" + array2[j] );  
				  }
			  }
			  }
			  
	}
      private static void bai8() {
    	  int x = 1;
  		int sum =0;
  		while (x != 0) {
  	      System.out.println("Nhập số nguyên bất kì, dừng lại khi nhập số 0:" );
  	      Scanner inp = new Scanner(System.in);
  	   	  x = inp.nextInt();
  	   	  sum = sum +x;
  	     }
  	 	System.out.println("tổng các số đã nhập là:" + sum);
         }
	
	private static void bai9() {
		System.out.println("*Find a city via a number*" );
		int a;
		    System.out.print("Enter a number: ");
		    Scanner scanner = new Scanner(System.in);
		    a= scanner.nextInt();
		    bai9.bai9(a);

	}
}

